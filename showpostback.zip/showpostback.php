
  <?php
  $servername = "localhost";
  $username = "jakeworks";
  $password = "qkrrhkdrb1!";
  $dbname = "jakeworks";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // DB name parameter
  $db = $_GET['a'];

  // pagination parameter
  if (isset($_GET['page'])) {
    // paging parameterS
    $page = $_GET['page'];
  } else {
    $page = 1;
  }
  // paging code
  $paging_sql = "SELECT count(*) FROM $db";
  $total_cnt = $conn->query($paging_sql);
  $list = 10;
      $block_cnt = 5;
      $block_num = ceil($page / $block_cnt);
      $block_start = (($blcok_num-1) * $block_cnt) + 1;

      $block_end = $block_start + $block_cnt - 1;

      $total_page = ceil($total_cnt / $list);
      if($block_end > $total_page){
        $block_end = $total_page;
      }

      $total_block = ceil($total_page / $block_cnt);
      $page_start = ($page -1) * $list;




  $sql = "SELECT * FROM $db ORDER BY event_date_time DESC LIMIT $page_start, $list";
  $result = $conn->query($sql);
  // HTML for table
  echo "
  <div class=\"col-md-1\"></div>
  <div class=\"col-md-10\">
        <table  class=\"table table-dark table-hover table-striped\">
        <tr>
        		<th>adid</th>
        		<th>idfv</th>
        		<th>model</th>
        		<th>language</th>
        		<th>detail_event_name</th>
        		<th>event_date_time</th>
	       </tr>
	       <tr>";
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo "<td>" . $row["adid"]. "</td><td>" . $row["idfv"]. "</td><td>" . $row["model"].
			"</td><td>". $row["language"]."</td><td>". $row["detail_event_name"]."</td><td>".$row["event_date_time"]."</td>";
			echo "</tr>";
    }
  } else {
    echo "0 results";
  }
  echo "</table>
      </div>
      <div class=\"col-md-1\"></div>";

  echo '<div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10" style = "text-align : center;">
            <ul class="pagination">';
  if ($page <= 1) {
  } else {
      echo '<li class="page-item"><a class="page-link" href="showpostback.php?a='.$db.'&page=1">begin</a></li>';
  }
  if ($page <= 1) {
  } else {
      $pre = $page - 1;
      echo '<li class="page-item"><a class="page-link" href="showpostback.php?a='.$db.'&page='.$pre.'">previous</a></li>';
  }

  for ($i=$block_start; $i <= $block_end ; $i++) {
      if ($page == $i) {
          echo '<li class="page-item">'.$i.'</li>';
      } else{
          echo '<li class="page-item"><a class="page-link" href="showpostback.php?a='.$db.'&page='.$i.'">'.$i.'</a></li>';
      }
  }

  if ($page >= $total_page) {
  } else {
    $next = $page + 1;
    echo '<li class="page-item"><a class="page-link" href="showpostback.php?a='.$db.'&page='.$next.'">next</a></li>';
  }

  if ($page >= $total_page) {

  } else {
    echo '<li class="page-item"><a class="page-link" href="showpostback.php?a='.$db.'&page='.$total_page.'">end</a></li>';
  }

    echo    '</ul>
      </div>
    <div class="col-md-1"></div>
</div>';

  $conn->close();

   ?>
